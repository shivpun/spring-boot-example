package com.ing.kafka.resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.ing.kafka.model.User;

@Component
public class UserReceive {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserReceive.class);

    @Autowired
    private KafkaTemplate<String, User> kafkaTemplate;
    
    @Value(value="${spring.kafka.topic.receiver}")
    private String receiver;
    
    @KafkaListener(topics = "${spring.kafka.topic.sender}")
    public User receive(String payload) {
      LOGGER.info("received payload='{}'", payload);
      Gson gson = new Gson();
      User user = gson.fromJson(payload, User.class);
      kafkaTemplate.send(receiver, user);
      return user;
    }
}
