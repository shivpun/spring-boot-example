package com.ing.kafka.model;

import java.util.Map;

import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.serialization.ExtendedSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class XmlSerializer<T> implements ExtendedSerializer<T> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(XmlSerializer.class);

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {}

	@Override
	public byte[] serialize(String topic, T data) {
		if (data == null) {
			return null;
		}
		XmlMapper xmlMapper = new XmlMapper();
	    try {
			return xmlMapper.writeValueAsBytes(data);
		} catch (JsonProcessingException e) {
			LOGGER.error("XmlSerializer | Topic:"+topic, e);
		}
		return null;
	}

	@Override
	public void close() {}

	@Override
	public byte[] serialize(String topic, Headers headers, T data) {
		return serialize(topic, data);
	}

}
