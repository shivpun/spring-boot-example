package com.ing.kafka.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ing.kafka.model.User;
import com.ing.kafka.resource.UserReceive;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootKafkaApplicationTests {
	
	  @Autowired
	  private UserReceive usrReceive;

	@Test
	public void contextLoads() {
	    String msg = "{\"name\":\"Sam\",\"dept\":\"IT\",\"salary\":8200}";
	    User user = usrReceive.receive(msg);
	    User usr = new User("Sam", "IT", 8200L);
	    assertEquals(user, usr);
	}

}
